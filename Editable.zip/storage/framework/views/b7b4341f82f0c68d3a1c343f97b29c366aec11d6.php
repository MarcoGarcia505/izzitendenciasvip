<!DOCTYPE html>
<html lang="en">
<head>
    <title>Kick Off 2021</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo e(url('public/images/Santander.svg')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/fonts/iconic/css/material-design-iconic-font.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/animate/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/css-hamburgers/hamburgers.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/animsition/css/animsition.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/select2/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/vendor/daterangepicker/daterangepicker.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/main.css')); ?>">
</head>
<body>

<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <form method="post" action="<?php echo e(route('_login')); ?>" class="alogin100-form">
				<span class="login100-form-title p-b-90">
					<i class=""> <img src="<?php echo e(url('public/images/Santanderrojo.svg')); ?>" alt=""></i>
				</span>
                <div class="wrap-input100 validate-input" data-validate="Ingresar correo valido">
                    <input class="input100" type="text" name="email" value="manager@santander.cwa">
                    <span class="focus-input100" data-placeholder="Email"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Ingresar una contraseña">
					<span class="btn-show-pass">
						<i class="zmdi zmdi-eye"></i>
					</span>
                    <input class="input100" type="password" name="password" value="123qwe">
                    <span class="focus-input100" data-placeholder="Password"></span>
                </div>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <div class="container-login100-form-btn">
                    <div class="wrap-login100-form-btn">
                        <div class="login100-form-bgbtn"></div>
                        <button type="submit" class="login100-form-btn">
                            <span class="bob">Login</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo e(url('public/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/animsition/js/animsition.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/bootstrap/js/popper.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(url('public/vendor/countdowntime/countdowntime.js')); ?>"></script>
<script src="<?php echo e(url('public/js/main-login.js')); ?>"></script>
</body>
</html>
<?php /**PATH /homepages/14/d853376993/htdocs/web2/resources/views/login.blade.php ENDPATH**/ ?>